import React from 'react'

const SecondartContainer = () => {
  return (
    <div>SecondartContainer</div>
  )
}

export default SecondartContainer